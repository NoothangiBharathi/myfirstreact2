const express = require('express')
const register = require('../controllers/registration')
const app = express.Router()
const emailverify = require('../controllers/verifyemail')
const verifypassword= require('../controllers/password')
const getuserdetails = require('../controllers/getuserdetails')
const updatedetails = require('../controllers/updatedetails')
const logout= require('../controllers/logout')


app.post('/register',register)
app.post('/verifypassword',verifypassword)
app.post('/verifyemail',emailverify)
app.get('/getuserdetails',getuserdetails)
app.post('/updatedetails',updatedetails)
app.get('/logout',logout)



module.exports=app