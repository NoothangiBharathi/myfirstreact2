
const getuser= require('../helpers/userdetails')

const getuserdetails = async (req,res)=>{

    try{
        const token = req.cookies.token || ""
        const user = await getuser(token)
        return res.status(200).json({
            message:"userdetails",
            data:user
        })
    
    }

    catch(error){
        console.log(error)
        return res.status(400).json({
            message:error,
            error:true
        })
    }
}

module.exports = getuserdetails