
const logout = async (req,res) =>{
    try{
        const cookies ={
            http:true,
            secure:true
           }

        return res.cookie('token','',cookies).status(200).send({
            messages:"logout successfull"
        })
    }
    catch(error){
        return res.status(500).send({
            messages:error.messages
        })
    }
}

module.exports= logout