
const usermodule = require('../moduel/usermodule')

const verifyemail = async (req,res)=>{
    
    try{
    const {email}= req.body
    const checkemail = await usermodule.findOne({
        email:email
    })

    if(!checkemail){
        return res.status(200).json({
            message:"user not regitser",
            error:true
        })
        }
        else{
            return res.status(200).json({
                message:"email verify",
                data:checkemail
            })
        }
}

    catch(error){
        res.status(500).json({
            message:"error message"+error,
            error:true
        })
    }
}

module.exports = verifyemail