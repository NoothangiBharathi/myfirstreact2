const userdetails=require('../helpers/userdetails')
const usermodule = require('../moduel/usermodule')

const updatedetails = async (req,res)=>{
    try{
    const token = req.cookies.token||""

    const user = await userdetails(token)

    const {name,profilepic}= req.body

    const updateuser = await usermodule.updateOne({_id:user._id},{
        name:name,
        profilepic:profilepic
    })

    const update = await usermodule.findById(user._id)

    return res.status(200).json({
        message:"succeussfulyy updated",
        data:update
    })

}

    catch(error){
        console.log(error)
        return res.status(500).json({
            error:error.message,
            message:500
        })
    }
    }

module.exports = updatedetails