
const usermodule = require('../moduel/usermodule')
const bcryjs = require ('bcryptjs')

const registration = async (req,res)=>{
   try{
      {console.log("console coming")}
     const {name,email,password,profile_pic}= req.body

     const emailverify = await usermodule.findOne({
        email:email
     })
     if(emailverify){
        return res.status(201).json({
            message:"user already register"
        })
     }
     const salt = await bcryjs.genSalt(10)
     const hashpassword = await bcryjs.hash(password,salt)

     const payload ={name,email,profile_pic,password:hashpassword}
        const newuser = new usermodule(payload);

  const usersave = await newuser.save()

        return res.status(200).json({
            message:"user succefully created",
            data:usersave, 
            success:true
        })
    
   }
   catch(error){
    return res.status(500).json({
        message:error,
        error:true
    })
   }
}

module.exports = registration