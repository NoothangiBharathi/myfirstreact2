const usermodule = require('../moduel/usermodule')
const bcryjs = require('bcryptjs')
const jwt = require('jsonwebtoken')
const verifypassword = async (req,res)=>{

    try{
        const {password,userid} = req.body
        
        const Userid = await usermodule.findById(userid)
        
        const pass = await bcryjs.compare(password,Userid.password)
        
        if(!pass){
            return res.status(400).json({
                message:"wrong password",
                error:true
            })
        }
     
        const tokendata ={
            id:Userid._id,
            email:Userid.email
        }
       const token =await jwt.sign(tokendata,process.env.JWT_SECRET_KEY,{expiresIn:'1d'})
       
       const cookies ={
        http:true,
        secure:true
       }
        
            return res.cookie('token',token,cookies).status(200).json({
                message:"login successfull",
                token:token,
                success:true
            })

    }
    catch(error){
        res.status(500).json({
            messages:"erro"+error,
            error:true
        })
    }
   

}

module.exports = verifypassword