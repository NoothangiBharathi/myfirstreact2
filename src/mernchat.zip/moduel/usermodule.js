const mongoose = require('mongoose')

const userdata = new mongoose.Schema({
    name:{
        type:String,
        required:[true,"provide name"]
    },
    email:{
        type:String,
        required:[true,"provide email"],
        unique:true
    },
    password:{
        type:String,
        required:[true,"provide passsword"]
    },
    profile_pic:{
        type:String,
        default:""
    }
},{timestamps:true}
)

const usermodule = mongoose.model('Userdetails',userdata)

module.exports = usermodule