

const mongoose = require('mongoose')


const messageschema = new mongoose.Schema({
    text:{
        type:String,
        default:""
    },
    image_url:{
        type:String,
        default:""
    },
    video_url:{
        type:String,
        default:""
    },
    seen:{
        type:Boolean,
        default:false
    }
}) 

const conversationdata = new mongoose.Schema({
    sender:{
        type:mongoose.Schema.ObjectId,
        required:true,
        ref:'Userdetails'
    },
    reciver:{
        type:mongoose.Schema.ObjectId,
        required:true,
        ref:'Userdetails'
    },
    message:[
        {
            type:mongoose.Schema.ObjectId,
            ref:'messages'
        }
    ]
},{timestamps:true})


const Messages = mongoose.model('messages',messageschema)
const converstaionmodel = mongoose.model('Conversationchat',conversationdata)

module.exports={
    Messages,
    converstaionmodel
}