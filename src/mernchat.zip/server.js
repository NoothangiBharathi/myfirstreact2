const express = require('express')
const createDbConnection = require('./database')
const app = express()
const cookies = require('cookie-parser')
const routes = require('./routes/route')
const cors = require('cors')
require('dotenv').config()
app.use(cookies())
const corsOptions = {
    origin: 'http://localhost:3002',  // Ensure this matches your frontend URL
    methods: 'GET,POST,PUT,DELETE',
    allowedHeaders: 'Content-Type',
    credentials: true  // Enable credentials
};

app.use(cors(corsOptions))

createDbConnection.createDbConnection()
app.use(express.json())

app.use('/api',routes)

app.listen('5000',()=>{
    console.log("your chat application is ruuning")
}) 


