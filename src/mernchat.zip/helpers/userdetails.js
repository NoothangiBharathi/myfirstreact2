const jwt = require('jsonwebtoken')

const usermodule = require('../moduel/usermodule')
const verifyuserdetails = async(token)=>{

    if(!token){
        return {
            messages:"session time out"
        }
    }
    console.log(process.env.JWT_SECRET_KEY)
    const decode = await jwt.verify(token,process.env.JWT_SECRET_KEY)
  console.log(decode)
  
    const user = await usermodule.findById(decode.id).select('-password')
    
    return user
}

module.exports = verifyuserdetails